import {W2} from "./W2";
import {F1099INT} from "./F1099INT";
import {TY2019_Form1040} from "./TY2019_Form1040";
import {TY2019_Schedule1} from "./TY2019_Schedule1";
import {TY2019_BH_Schedule_C} from "./TY2019_BH_Schedule_C";
import {TY2019_BH_Schedule_K1} from "./TY2019_BH_Schedule_K1";

export function single2019_BH() {
    const w2: W2[] = [{
        box1income: 170830.99,
        payer: 'Airbnb',
        electiveDeferrals_D: 19000,
        socialSecurityWages: 170830.99
    }];

    const bwh_interest: F1099INT[] = [
        {payer: 'Betterment', taxExemptInterest: 0, taxableInterest: 2212 },
        {payer: 'Customers Bank', taxExemptInterest: 0, taxableInterest: 64 },
        {payer: 'Ally Bank', taxExemptInterest: 0, taxableInterest: 3687.05 },
        {payer: 'Nat Financial Svc LLC', taxExemptInterest: 0, taxableInterest: 22.47 },
        {payer: 'Ally Bank (Joint)', taxExemptInterest: 0, taxableInterest: 33.58 },
        {payer: 'AMEX', taxExemptInterest: 0, taxableInterest: 1327 },
        {payer: 'Capital One', taxExemptInterest: 0, taxableInterest: 621 }
    ];

    const f1040 = new TY2019_Form1040();
    const schedule1 = new TY2019_Schedule1();
    schedule1.inputs.scheduleC = [new TY2019_BH_Schedule_C()];
    schedule1.inputs.scheduleE.k1 = [new TY2019_BH_Schedule_K1()];
    schedule1.inputs.w2 = w2;
    schedule1.inputs.max_elective_deferrals = 19000; // 2019
    schedule1.inputs.max_defined_benefit_contrib = 56000; // 2019

    f1040.inputs = {
        wages: w2,
        interest: bwh_interest,
        dividends: [
            { payer: 'PSEG', qualified: 993, ordinary: 993},
            { payer: 'Nat Financial Svc LLC', qualified: 2286, ordinary: 2563, capitalGains: 7, div199a: 37, foreignTaxPaid: 28},
            { payer: 'Robinhood', qualified: 11, ordinary: 11},
            { payer: 'Total for long term transactions (1099B)', qualified: 0, ordinary: 0, capitalGains: 15074 - 14633},
        ], // schedule b and d
        schedule1,
        type: 'single',
        qbiQualifiedPropertyUnadjustedBasis: (542.49+710.34+606+2099+269)
    };
    return f1040;
}