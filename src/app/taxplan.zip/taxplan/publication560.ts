export function p560(
    schC_line31_plus_k1_net_income: number,
    sch1_line14: number,
    elective_deferrals: number,
    max_defined_contribution = 57000) {

    const line1 = {t: 'schedule c line 31, net profit plus any income from K1', val: schC_line31_plus_k1_net_income}; // 8815.01175029171
    const line2 = {t: 'schedule 1 line 14, deduction for SE tax', val: sch1_line14}; // 118.039618595219
    const line3 = {t: 'line 1 - line 2: net earnings from self-employment', val: line1.val - line2.val};
    const line4 = {t: 'reduced contribution rate from rate table for self-employed @ 25%', val: 0.20};
    const line5 = {t: 'line 3 x line 4', val: line3.val * line4.val};
    const line6 = {t: '$280,000 x 25% (plan contribution rate, not reduced contribution rate)', val: 70000};
    const line7 = {t: 'smaller of line 5 or line 6', val: Math.min(line5.val, line6.val)}; // 1739.3944263393

    //https://www.plansponsor.com/irs-announces-2020-contribution-benefit-limits/
    const line8 = {t: '2020 contribution dollar limit = $57,000', val: max_defined_contribution};

    const line9 = {t: 'allowable elective deferrals to self-employed plan, 2020 max = $19,500', val: Math.min(elective_deferrals, line3.val)}; //TODO: This should come from input

    if (elective_deferrals > line3.val) {
        console.error("Elective deferrals exceeded net earnings from self employment");
    }

    const line10 = {t: 'line 8 - line 9', val: line8.val - line9.val};
    const line11 = {t: 'line 3 - line 9', val: line3.val - line9.val};
    const line12 = {t: '0.5 x line 11', val: 0.5 * line11.val};
    const line13 = {t: 'smallest of lines 7, 10 and 12', val: Math.min(Math.min(line7.val, line10.val), line12.val)};
    const line14 = {t: 'line 3 - line 13', val: line3.val - line13.val};
    const line15 = {t: 'smaller of lines 9 and 14', val: Math.min(line9.val, line14.val)};
    const line16 = {t: 'line 14 - line 15', val: line14.val - line15.val};
    const line17 = {t: 'catch-up contributions', val: 0};
    const line18 = {t: 'smaller of lines 16 and 17', val: Math.min(line16.val, line17.val)};
    const line19 = {t: 'lines 13 + 15 +18', val: line13.val + line15.val + line18.val};
    const line20 = {t: 'designated Roth contributions from lines 9 and 17', val: 0};
    const line21 = {t: 'line 19 - line 20: maximum deductible contribution', val: line19.val - line20.val};

    return {
        title: 'Pub 560',
        line1,
        line2,
        line3,
        line4,
        line5,
        line6,
        line7,
        line8,
        line9,
        line10,
        line11,
        line12,
        line13,
        line14,
        line15,
        line16,
        line17,
        line18,
        line19,
        line20,
        line21,
    };
}
