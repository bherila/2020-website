export class Form8829 {
    public title = 'Form 8829';

    public l1_area_used_for_biz = 96;
    public l2_total_area = 857;

    // line 16-22
    public rent = 0;
    public utilities = 0;

    public calculate(c29: number) {
        const l1 = {t: 'area used regularly and exclusively for business', val: this.l1_area_used_for_biz};
        const l2 = {t: 'total area of home', val: this.l2_total_area};
        const l7 = {t: 'business percentage', val: l1.val / l2.val};
        const l15 = {t: 'amt from sch c line 29', val: c29};
        const l23 = {t: 'add line 16 through 22', val: this.rent + this.utilities};
        const l26 = {t: 'multiple line 23 column b times line 7', val: l23.val * l7.val};
        const l25 = {t: 'min (line 15, line 26)', val: Math.min(l15.val, l26.val)}

        return {
            title: this.title,
            l1,
            l2,
            l7,
            l15,
            l23,
            l26,
            l25,
        };
    }

}
