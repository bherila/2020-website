import {W2} from "./W2";
import {F1099INT} from "./F1099INT";
import {TY2019_Form1040} from "./TY2019_Form1040";
import {TY2019_Schedule1} from "./TY2019_Schedule1";
import {TY2019_JY_Schedule_C} from "./TY2019_JY_Schedule_C";

export function single2019_JY() {
    const w2: W2[] = [{
        box1income: 61003.65,
        payer: 'County',
        electiveDeferrals_D: 0,
        socialSecurityWages: 61003.65
    }];

    const bwh_interest: F1099INT[] = [
        {payer: 'Alliant', taxExemptInterest: 0, taxableInterest: 29.81 },
        {payer: 'Ally Bank', taxExemptInterest: 0, taxableInterest: 29.66 },
    ];

    const f1040 = new TY2019_Form1040();
    const schedule1 = new TY2019_Schedule1();
    schedule1.inputs.scheduleC = [new TY2019_JY_Schedule_C()];
    schedule1.inputs.scheduleE.k1 = [];
    schedule1.inputs.scheduleE.rental_income_or_loss =  -12523.14; // TODO: Build the form
    schedule1.inputs.w2 = w2;
    schedule1.inputs.max_elective_deferrals = 19000; // 2019
    schedule1.inputs.max_defined_benefit_contrib = 56000; // 2019
    schedule1.inputs.ret1 = {
        ira_contrib: 6000,
        covered: false
    };

    f1040.inputs = {
        wages: w2,
        interest: bwh_interest,
        dividends: [], // schedule b and d
        schedule1,
        type: 'single',
        qbiQualifiedPropertyUnadjustedBasis: 0
    };
    return f1040;
}
