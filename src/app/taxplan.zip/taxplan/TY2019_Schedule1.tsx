import {p560} from "./publication560";
import {sum} from "./sum";
import {ScheduleC} from "./TY2019_ScheduleC";
import {W2} from "./W2";

export class TY2019_Schedule1 {

    public inputs = {
        scheduleC: [] as ScheduleC[],
        w2: [] as W2[],
        max_elective_deferrals: 19500, //2020 figure
        max_defined_benefit_contrib: 70000, //2020 figure,
        scheduleE: {
            k1: [] as ScheduleC[],
            rental_income_or_loss: 0,
        },
        socialSecurityWageLimit: 132900,
        
        type: 'single' as 'single' | 'married',
        ret1: {
            covered: false,
            ira_contrib: 0,
        },
        ret2: {
            covered: false,
            ira_contrib: 0,
        }
    };
    
    public iraDeductionWorksheet(f1040_line7b: number, deductions_so_far: number, s1line3: number, s1line14: number, s1line15: number) {
        const w1a = this.inputs.ret1.covered;
        const w1b = this.inputs.ret2.covered;
        
        /* 
        Next. If you checked “No” on line 1a (and “No” on line 1b if married filing
        jointly), skip lines 2 through 6, enter the applicable amount below on line 7a
        (and line 7b if applicable), and go to line 8.
        • $6,000, if under age 50 at the end of 2019.
        • $7,000, if age 50 or older but under age 701/2 at the end of 2019.
         Otherwise, go to line 2.
        */
        let w2a = 0;
        let w2b = 0;
        let w3 = 0;
        let w4 = 0;
        let w5a = 0;
        let w5b = 0;
        let w6a = 0;
        let w6b = 0;
        let w7a = 0;
        let w7b = 0;
        if (w1a || w1b) {
            /*
            Line 2 
            Enter the amount shown below that applies to you.
            • Single, head of household, or married filing separately and you
              lived apart from your spouse for all of 2019, enter $74,000.
            • Qualifying widow(er), enter $123,000. 2a. 2b.
            • Married filing jointly, enter $123,000 in both columns. But if you checked
              “No” on either line 1a or 1b, enter $203,000 for the person who wasn't covered by a plan.
            • Married filing separately and you lived with your spouse at any time in 2019, enter $10,000
             */
            if (this.inputs.type === 'single') {
                w2a = 74000;
            } else {
                if (w1a && w1b) {
                    w2a = 123000;
                    w2b = 123000;
                } else if (w1a) {
                    w2a = 0;
                    w2b = 203000;
                } else if (w1b) {
                    w2a = 203000;
                    w2b = 0;
                }
            }
            
            /* Enter the amount from Form 1040 or 1040-SR, line 7b .*/
            w3 = f1040_line7b;
            
            /* Enter the total of the amounts from Schedule 1, lines
            10 through 18a, plus any write-in adjustments you
            entered on the dotted line next to Schedule 1,
            line 22 */
            w4 = deductions_so_far;
            
            /* Subtract line 4 from line 3. If married filing jointly, enter the result in both columns */
            w5a = w3 - w4;
            if (this.inputs.type === 'married') {
                w5b = w3 - w4;
            }
            
            /* Is the amount on line 5 less than the amount on line 2?
                No.
                    STOP
                    None of your IRA contributions are deductible. For details on
                    nondeductible IRA contributions, see Form 8606.
                Yes. 
                    Subtract line 5 from line 2 in each column. Follow the instruction
                    below that applies to you.
                    • If single, head of household, or married filing separately,
                        and the result is $10,000 or more, enter the applicable
                        amount below on line 7 for that column and go to line 8.
                        i. $6,000, if under age 50 at the end of 2019.
                        ii. $7,000, if age 50 or older but under age 70 1/2 at the
                        end of 2019.
                    If the result is less than $10,000, go to line 7.
                    • If married filing jointly or qualifying widow(er), and the
                        result is $20,000 or more ($10,000 or more in the column
                        for the IRA of a person who wasn't covered by a
                        retirement plan), enter the applicable amount below on
                        line 7 for that column and go to line 8.
                        i. $6,000, if under age 50 at the end of 2019.
                        ii. $7,000 if age 50 or older but under age 701/2 at the
                        end of 2019.
                    Otherwise, go to line 7 */
            w6a = Math.max(0, w2a - w5a);
            w6b = Math.max(0, w2b - w5b);

            if (this.inputs.type === 'single') {
                if (w6a >= 10000) {
                    w7a = 6000;
                } // if less than 10000 go to line 7
                else {
                    /* 7. Multiply lines 6a and 6b by the percentage below that applies to you. If the
                        result isn't a multiple of $10, increase it to the next multiple of $10 (for
                        example, increase $490.30 to $500). If the result is $200 or more, enter the
                        result. But if it is less than $200, enter $200.
                        • Single, head of household, or married filing separately, multiply by 60%
                        (0.60) (or by 70% (0.70) in the column for the IRA of a person who is age
                        50 or older at the end of 2019).
                        */                    
                    w7a = w6a * 0.60;
                    w7a = Math.ceil(w7a / 10) * 10; // increase to next multiple of 10
                }
                if (w6b > 0) throw 'not married!';
                // if (w6b >= 10000) {
                //     w7b = 6000;
                // } else {
                //    
                // }
            }
            if (this.inputs.type === 'married') {
                if (w6a >= 20000 || (!this.inputs.ret1.covered && w6a > 10000)) {
                    w7a = 6000;
                } else {
                    /* • Married filing jointly or qualifying widow(er), multiply by 30% (0.30)
                     (or by 35% (0.35) in the column for the IRA of a person who is age 50 or
                    older at the end of 2019). But if you checked “No” on either line 1a
                    or 1b, then in the column for the IRA of the person who wasn't covered by a
                    retirement plan, multiply by 60% (0.60) (or by 70% (0.70) if age 50 or
                    older at the end of 2019). */
                    w7a = w6a * 0.3;
                    w7a = Math.ceil(w7a / 10) * 10; // increase to next multiple of 10
                }
                if (w6b >= 20000 || (!this.inputs.ret2.covered && w6b > 10000)) {
                    w7b = 6000;
                } else {
                    w7b = w6b * 0.3;
                    w7b = Math.ceil(w7b / 10) * 10; // increase to next multiple of 10
                }
            }
        }
        else {
            if (!w1a) {
                w7a = 6000;
            }
            if (!w1b && this.inputs.type === 'married') {
                w7b = 6000;
            }
        }

        const w8 = this.inputs.w2.map(w2 => w2.box1income).reduce((a, b) => a+b, 0);
        const w9 = s1line3 - s1line14 - s1line15;
        const w10 = w8 + w9;
        const w11a = this.inputs.ret1.ira_contrib;
        const w11b = this.inputs.ret2.ira_contrib;
        const w12a = {t: 'IRA deduction for #1', val: Math.min(w7a, w10, w11a)};
        const w12b = {t: 'IRA deduction for #2', val: Math.min(w7b, w10, w11b)};
        const result = {t: 'Total IRA deduction', val: sum([w12a, w12b])};
        
        return {
            w2a: {t: '2a', val: w2a},
            w2b: {t: '2b', val: w2b},
            w6a: {t: '6a', val: w6a},
            w6b: {t: '6b', val: w6b},
            w7a: {t: 'IRA Limit #1', val: w7a},
            w7b: {t: 'IRA Limit #2', val: w7b},
            w12a, 
            w12b, 
            result
        };
    }

    public calculateSE() {
        return [
            ...this.inputs.scheduleC,
            ...this.inputs.scheduleE.k1
        ].map(c => this.scheduleSE(c));
    }

    private scheduleSE(input: ScheduleC) {
        const se2 = { t: 'net profit from schedule c line 31 or k1', val: input.calculate().l31.val };
        const se3 = { t: 'add line 1a+1b+2', val: se2.val };
        const se4a = { t: 'if (l3 > 0) *= 92.35', val: se3.val * 0.9235 };
        const se4b = { t: 'enter total of line 15 + 17 (optional method)', val: 0 }; // not elected.
        const se4c = { t: 'combine 4a+4b', val: se4a.val + se4b.val };
        const se5ab = { t: 'church', val: 0 };
        const se6 = { t: 'add 4c + 5b', val: se4c.val + se5ab.val };
        const se7 = { t: 'social security wage limit', val: this.inputs.socialSecurityWageLimit };
        const se8a = { t: 'total social security wages from W-2', val: this.inputs.w2.reduce((a, b) => a + b.socialSecurityWages, 0) };
        const se8b = { t: 'tips', val: 0 };
        const se8c = { t: 'wages subj. to ss. Tax (form 8919, only if not already withheld)', val: 0 };
        const se8d = { t: 'add 8a+8b+8c', val: se8a.val + se8b.val + se8c.val };
        const se9 = { t: 'subtract line 7 - line 8d (if <0, enter 0)', val: Math.max(0, se7.val - se8d.val) };
        const se10 = { t: 'multiply min (line 6, line 9) * 12.4%', val: Math.min(se6.val, se9.val) * 0.124 };
        const se11 = { t: 'line 6 * 2.9%', val: se6.val * 0.029 };
        const se12 = { t: 'add line 10 + line 11', val: se10.val + se11.val };
        const se13 = { t: 'line 12 * 50%', val: se12.val * 0.50 };
        return {title: 'Sch SE', se2, se3, se4a, se4b, se4c, se5ab, se6, se7, se8a, se8b, se8c, se8d, se9, se10, se11, se12, se13};
    }

    public calculate(f1040_line7b: number) {
        const {
            scheduleC,
            max_elective_deferrals,
            max_defined_benefit_contrib,
        } = this.inputs;

        // add up W2 elective deferrals already done
        const w2_elective_deferrals = this.inputs.w2
            .map(x => x.electiveDeferrals_D || 0)
            .reduce((a, b) => a + b, 0);
        
        const scheduleE = {
            e1: {t: 'k-1 total', val: this.inputs.scheduleE.k1.reduce((a, b) => a + b.calculate().l31.val || 0, 0)},
            e2: {t: 'real estate total', val: this.inputs.scheduleE.rental_income_or_loss}
        };

        const income = {
            s1line1: {t: 'taxable refunds, credits, or offsets of state and local income taxes', val: 0}, //no ca or il 1099g
            s1line2: {t: 'alimony received', val: 0}, //
            s1line3: {t: 'business income or (loss). attach schedule C', val: 0, subForm: null as any}, //from schedule c, line 31
            s1line4: {t: 'other gains or (losses). attach form 4797', val: 0}, //
            s1line5: {
                t: 'rental, real estate, royalities, partnerships, S-corporations, trusts, etc. attach schedule E',
                val: sum([scheduleE.e1, scheduleE.e2]),
                subForm: scheduleE
            }, //from schedule e, the only thing on here is k-1 income
            s1line6: {t: 'farm income or (loss). attach schedule F', val: 0}, //
            s1line7: {t: 'unemployment compensation', val: 0}, //
            s1line8: {t: 'other income. list type and amount', val: 0}, //
        };

        const cCalc = scheduleC.map(c => c.calculate());
        income.s1line3.subForm = cCalc;
        income.s1line3.val = sum(cCalc.map(c => c.l31));

        const se = this.calculateSE();
        
        const adjustments = {
            s1line10: {t: 'educator expenses', val: 0}, //
            s1line11: {t: 'n/a performing artists, etc.', val: 0}, //
            s1line12: {t: 'health savings account deduction. see form 8889', val: 0}, //
            s1line13: {t: 'moving expenses for members of the armed forces.', val: 0}, //
            s1line14: {
                t: 'deductible part of self-employment tax. attach schedule SE',
                val: se.reduce((a, b) => a + b.se13.val || 0, 0),
                subForm: se || null
            }, //from long schedule se
            s1line15: {t: 'self-employed SEP, SIMPLE, and qualified plans', val: 0, subForm: null as any}, //from publication 560 worksheet, line 21
            s1line16: {t: 'self-employed health insurance deduction', val: 0}, //
            s1line17: {t: 'penalty on early withdrawal of savings', val: 0}, //
            s1line18a: {t: 'alimony paid', val: 0}, //
        };

        adjustments.s1line15.subForm = p560(
            se.reduce((a, b) => a + b.se2.val, 0), // schedule c line 31
            adjustments.s1line14.val, max_elective_deferrals - w2_elective_deferrals,
            max_defined_benefit_contrib
        );
        adjustments.s1line15.val = adjustments.s1line15.subForm.line21.val;

        const ira = this.iraDeductionWorksheet(
            f1040_line7b, 
            sum(adjustments), 
            income.s1line3.val, 
            adjustments.s1line14.val, 
            adjustments.s1line15.val
        );
        
        const adjustments2 = {
            s1line19: {t: 'IRA deduction', val: ira?.result.val || 0, subForm: ira}, //TODO: income too high, phased out
            s1line20: {t: 'student loan interest deduction', val: 0}, //
            s1line21: {t: 'tuition and fees. attach form 8917.', val: 0}, //
        }

        const s1line9 = {t: 'combine lines 1-8. enter here & on form 1040 line 7a', val: sum(income)}; //to 1040 line 7a
        const s1line22 = {
            t: 'combine lines 10-21 = adjustments to income. enter here & on form 1040 line 8a', 
            val: sum(adjustments) + sum(adjustments2)
        }; //to 1040 line 8a

        return {
            title: 'Schedule 1',
            ...income,
            s1line9,
            ...adjustments,
            ...adjustments2,
            s1line22
        };
    }
}