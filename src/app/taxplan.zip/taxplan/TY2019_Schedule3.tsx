export class Schedule3 {

    public l1_foreign_tax_credit = 0;

    public l6_other_credits = 0;

    public calculate() {
        const {l1_foreign_tax_credit, l6_other_credits} = this;
        return {
            l1_foreign_tax_credit,
            l6_other_credits,
            sch3_l7: l1_foreign_tax_credit + l6_other_credits
        };
    }

}