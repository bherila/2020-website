import * as RS from "reactstrap";
import React from "react";

export interface Tval {
    t: string;
    v: number;
    subForm: any;
}

export function renderForm(form: any) {
    if (Array.isArray(form)) {
        return <React.Fragment>
            {form.map(f => renderForm(f))}
        </React.Fragment>;
    }
    return (
        <RS.Card>
            {!!form.title && <RS.CardTitle><h3 style={{textAlign: 'right'}}>{form.title}</h3></RS.CardTitle>}
            <RS.CardBody>
            <RS.Table size="sm" borderless>
                <tbody>
                {Object.keys(form)
                    .filter(key => key !== 'title')
                    .map(key => {
                        if (typeof form[key] === 'undefined' || form[key] === null) {
                            return null;
                        }
                        if (typeof form[key].val === 'number') {
                            if (form[key].val === 0) {
                                // return false;
                            }
                            return (
                                <React.Fragment key={key}>
                                    <tr>
                                        <td style={{textAlign: "right"}}>{form[key].t}</td>
                                        <td style={{textAlign: "right", width: '175px', opacity: form[key].val === 0 ? 0.5 : 1}}>{form[key].val.toFixed(2)}</td>
                                        <td style={{textAlign: "right", width: '100px'}}>{key}</td>
                                    </tr>
                                    {form[key].subForm && <tr>
                                        <td colSpan={3} style={{paddingLeft: '5%', paddingRight: '5%'}}>{renderForm(form[key].subForm)}</td>
                                    </tr>}
                                </React.Fragment>
                            );
                        }

                        // Handle singluar values
                        let displayName = key;
                        let lineNumber = '-';
                        const keyParts = key.split('_', 2);
                        if (keyParts.length === 2) {
                            displayName = keyParts[1];
                            lineNumber = keyParts[0];
                        }
                        if (typeof form[key] === 'string') {
                            return (
                                <tr key={key}>
                                    <td style={{textAlign: "right"}}>{displayName}</td>
                                    <td style={{textAlign: "right"}}>{form[key]}</td>
                                    <td style={{textAlign: "right"}}>{lineNumber}</td>
                                </tr>
                            )
                        }
                        if (typeof form[key] === 'number') {
                            return (
                                <tr key={key}>
                                    <td style={{textAlign: "right"}}>{displayName}</td>
                                    <td style={{textAlign: "right", opacity: form[key] === 0 ? 0.5 : 1}}>{form[key].toFixed(2)}</td>
                                    <td style={{textAlign: "right"}}>{lineNumber}</td>
                                </tr>
                            )
                        }
                        return null;
                    }).filter(x => x != null)}
                </tbody>
            </RS.Table>
            </RS.CardBody>
        </RS.Card>
    );
}
