export interface F1099INT {
    payer: string;
    taxableInterest: number;
    taxExemptInterest: number;
}