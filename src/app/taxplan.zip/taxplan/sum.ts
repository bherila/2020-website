export function sum(tVals: any): number {
    const res = Object.keys(tVals)
        .map(expense => typeof tVals[expense].val === 'number' ? tVals[expense].val : tVals[expense])
        .filter(val => typeof val === 'number')
        .reduce((a, b) => a + b, 0)
    return res || 0;
}
