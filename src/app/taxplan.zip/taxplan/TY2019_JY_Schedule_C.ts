import {ScheduleC} from "./TY2019_ScheduleC";
import {Form8829} from "./TY2019_Form8829";

export class TY2019_JY_Schedule_C extends ScheduleC {
    constructor() {
        super();
        this.info = {
            "principal business/profession": "All other professional, scientific, & technical services",
            "enter code from instructions": "541990",
            "business name": "(BLANK)",
            "business address": "99 RAUSCH ST APT 526",
            "accounting method": "CASH",
            "did you materially participate?": "✔",
            "did you start or acquire this business in 2019?": "YES",
            "must file form 1099?": "NO",
            "will you file all required forms 1099?": "",
        }

        this.expenses = {
            'l8_advertising': 0,
            'l9_car and truck expense': 0,
            'l10_commissions and fees': 0,
            'l11_contract labor': 0,
            'l12_depletion': 0,
            'l13_depreciation and sec 179 expense': 0,
            'l14_employee benefits': 0,
            'l15_insurance (not health)': 0,
            'l16_interest': 0,
            'l17_legal': 0,
            'l18_office expense': 0,
            'l19_pension and profit sharing': 0,
            'l20_rent or lease': 0,
            'l21_repairs and maintenance': 0,
            'l22_supplies': 0,
            'l23_taxes and licenses': 0,
            'l24a_travel': 0,
            'l24b_deductible meals': 0,
            'l25_utilities': 0,
            'l26_wages': 0,
            'l27a_other_expenses': 0,
        };

        this.gross_receipts = 21500;
        this.returns = 250;
        this.other_income = 0;

        // HOME OFFICE DEDUCTION WORKSHEET
        // this.form8829 = new Form8829();
        // this.form8829.rent = 0;
        // this.form8829.utilities = 0;
    }
}

