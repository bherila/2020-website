
import React from "react";
import {TY2019_Schedule1} from "./TY2019_Schedule1";
import {QBI_PHASEOUT_SINGLE_2019, QBI_THRESH_SINGLE_2019, TY2019_Form8995A} from "./TY2019_Form8995A";
import {sum} from "./sum";
import {F1099DIV} from "./F1099DIV";
import {F1099INT} from "./F1099INT";
import {W2} from "./W2";
const SD_SINGLE = 12200;
const SD_MARRIED = 12200 * 2;

export class TY2019_Form1040 {

    public inputs = {
        wages: [] as W2[],
        interest: [] as F1099INT[],
        dividends: [] as F1099DIV[],
        schedule1: null as TY2019_Schedule1 | null,
        qbiQualifiedPropertyUnadjustedBasis: 0,
        type: 'single' as ('single' | 'married'),
    };

    public scheduleD() {
        // long term cap gains
        const {dividends} = this.inputs;
        return {
            title: 'Schedule D',
            l15: {t: 'long term capital gains', val: dividends
                    .map(div => div.capitalGains || 0)
                    .reduce((a, b) => a + b, 0)}
        };
    }

    public getStandardDeduction() {
        return this.inputs.type === 'single' ? SD_SINGLE : SD_MARRIED;
    }

    public calculate() {
        const schD = this.scheduleD();
        let sch1 = this.inputs.schedule1?.calculate(0);

        const l1 = {t: 'wages, salaries, tip. attach w2', val: this.inputs.wages.reduce((a, b) => a + b.box1income, 0)};
        const l2a = {t: 'tax-exempt interest', val: this.inputs.interest.reduce((a, b) => a + b.taxExemptInterest, 0)};
        const l2b = {t: 'taxable interest', val: this.inputs.interest.reduce((a, b) => a + b.taxableInterest, 0)};
        const l3a = {t: 'qualified dividends', val: this.inputs.dividends.reduce((a, b) => a + b.qualified, 0)};
        const l3b = {t: 'ordinary dividends', val: this.inputs.dividends.reduce((a, b) => a + b.ordinary, 0)};
        const l4a = {t: 'ira distributions, total', val: 0};
        const l4b = {t: 'ira distributions, taxable', val: 0};
        const l4c = {t: 'pensions and annuities, total', val: 0};
        const l4d = {t: 'pensions and annuities, taxable', val: 0};
        const l5a = {t: 'social security benefits, total', val: 0};
        const l5b = {t: 'social security benefits, taxable', val: 0};
        const l6 = {t: 'capital gain or loss. schedule d line 15', val: schD.l15.val || 0, subForm: schD};
        const l7a = {t: 'other income from schedule 1, line 9', val: sch1?.s1line9.val || 0};
        const l7b = {
            t: 'total income. lines 1 + 2b + 3b + 4b + 4d + 5b + 6 + 7a',
            val: l1.val + l2b.val + l3b.val + l4b.val + l4d.val + l5b.val + l6.val + l7a.val
        };

        // update schedule 1 with l7b
        sch1 = this.inputs.schedule1?.calculate(l7b.val);

        const l8a = {t: 'adjustments to income from schedule 1, line 22', val: (sch1?.s1line22.val) || 0};
        const l8b = {t: 'line 7b - line 8a = adjusted gross income, AGI', val: l7b.val - l8a.val};
        const l9 = {t: 'standard deduction', val: this.getStandardDeduction() || 9999999};
        const l9b = {t: 'taxable income before QBI deduction', val: l8b.val - l9.val};

        let form8995A: TY2019_Form8995A | null = null;
        if (this.inputs.schedule1) {
            form8995A = new TY2019_Form8995A(this.inputs.schedule1, this.inputs.type === 'single');
            form8995A.phase_in_range = QBI_PHASEOUT_SINGLE_2019;
            form8995A.threshold = QBI_THRESH_SINGLE_2019;
            form8995A.total_ubia = this.inputs.qbiQualifiedPropertyUnadjustedBasis;
        }
        const reit_dividends_199a = sum(this.inputs.dividends.map(x => (
            {t: 'sec.199a dividends', val: x.div199a || 0}
        )));
        const form8995A_calc = form8995A?.calculate(l9b.val, sum([l6, l3a]), reit_dividends_199a);
        const l10 = {
            t: 'qualified business income deduction. attach form 8995',
            val: form8995A_calc?.l39.val || 0,
            subForm: form8995A_calc
        };

        const l11a = {t: 'line 9 + line 10', val: l9.val + l10.val};
        const l11b = {t: 'line 8b - 11a: taxable income', val: l8b.val - l11a.val};
        const l11c = {t: 'tax (calculated)', val: 0};
        const l12a = {t: 'tax from table', val: 0};
        const l12b = {t: 'line 12a + schedule 2, line 3', val: l12a.val}; // TODO: AMT
        const l13a = {t: 'child tax credit or credit for dependents', val: 0};
        const l13b = {t: 'schedule 3 line 7 + 13a', val: l13a.val}; // TODO: Credits Schedule 3
        const l14 = {t: 'line 12b - 13b', val: l12b.val - l13b.val};
        const l15 = {
            t: 'other taxes, including self-employment tax',
            val: this.inputs.schedule1?.calculateSE().reduce((a, b) => a + b.se12.val || 0, 0) || 0,
        }; // schedule 2 line 10 only item SE tax
        const l16 = {t: 'total tax: lines 14 + 15', val: l14.val + l15.val};
        const sch1form = {t: 'Schedule 1', val: 0, subForm: sch1};
        return {
            title: 'Federal Form 1040',
            l1,
            l2a,
            l2b,
            l3a,
            l3b,
            l4a,
            l4b,
            l4c,
            l4d,
            l5a,
            l5b,
            l6,
            l7a,
            l7b,
            l8a,
            l8b,
            l9,
            l9b,
            l10,
            l11a,
            l11b,
            l11c,
            l12a,
            l12b,
            l13a,
            l13b,
            l14,
            l15,
            l16,
            sch1form
        };
    }
}
