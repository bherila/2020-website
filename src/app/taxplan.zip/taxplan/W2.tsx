export interface W2 {
    payer: string;
    box1income: number;
    electiveDeferrals_D: number;
    socialSecurityWages: number;
    healthPlanCost_DD?: number;
}