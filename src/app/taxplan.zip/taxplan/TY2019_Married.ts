import {F1099INT} from "./F1099INT";
import {TY2019_Form1040} from "./TY2019_Form1040";
import {TY2019_Schedule1} from "./TY2019_Schedule1";
import {TY2019_BH_Schedule_C} from "./TY2019_BH_Schedule_C";
import {TY2019_BH_Schedule_K1} from "./TY2019_BH_Schedule_K1";
import {TY2019_JY_Schedule_C} from "./TY2019_JY_Schedule_C";

export function married2019() {
    const f1040 = new TY2019_Form1040();
    const schedule1 = new TY2019_Schedule1();
    schedule1.inputs.scheduleE.k1 = [
        new TY2019_BH_Schedule_K1()
    ];
    schedule1.inputs.scheduleC = [
        new TY2019_BH_Schedule_C(),
        new TY2019_JY_Schedule_C(),
    ];
    schedule1.inputs.w2 = [{
        box1income: 126217.92,
        payer: 'Airbnb',
        electiveDeferrals_D: 9545.95,
        healthPlanCost_DD: 2825.90,
        socialSecurityWages: 132900.00
    },{
        box1income: 44613.08,
        payer: 'Underground',
        electiveDeferrals_D: 9386.88,
        healthPlanCost_DD: 2418.24,
        socialSecurityWages: 53999.96
    },{
        box1income: 61003.65,
        payer: 'County',
        electiveDeferrals_D: 0,
        healthPlanCost_DD: 8580.62,
        socialSecurityWages: 61003.65
    }];
    schedule1.inputs.max_elective_deferrals = 19000; // 2019
    schedule1.inputs.max_defined_benefit_contrib = 56000; // 2019
    schedule1.inputs.scheduleE.rental_income_or_loss =  0; // Not allowed because of MAGI limitation > $100K. TODO: Build the form
    schedule1.inputs.type = 'married';
    schedule1.inputs.ret1 = {
        ira_contrib: 0,
        covered: true,
    };
    schedule1.inputs.ret2 = {
        ira_contrib: 0,
        covered: false,
    };

    const jy_interest: F1099INT[] = [
        {payer: 'Alliant', taxExemptInterest: 0, taxableInterest: 29.81 },
        {payer: 'Ally Bank', taxExemptInterest: 0, taxableInterest: 29.66 },
    ];
    const bwh_interest: F1099INT[] = [
        {payer: 'Betterment', taxExemptInterest: 0, taxableInterest: 2212 },
        {payer: 'Customers Bank', taxExemptInterest: 0, taxableInterest: 64 },
        {payer: 'Ally Bank', taxExemptInterest: 0, taxableInterest: 3687.05 },
        {payer: 'Nat Financial Svc LLC', taxExemptInterest: 0, taxableInterest: 22.47 },
        {payer: 'Ally Bank (Joint)', taxExemptInterest: 0, taxableInterest: 33.58 },
        {payer: 'AMEX', taxExemptInterest: 0, taxableInterest: 1327 },
        {payer: 'Capital One', taxExemptInterest: 0, taxableInterest: 621 }
    ];

    f1040.inputs = {
        wages: schedule1.inputs.w2,
        interest: [
            ...jy_interest,
            ...bwh_interest
        ],
        dividends: [
            { payer: 'PSEG', qualified: 993, ordinary: 993},
            { payer: 'Nat Financial Svc LLC', qualified: 2285.75, ordinary: 2562.97, capitalGains: 7.10, div199a: 37, foreignTaxPaid: 28},
            { payer: 'Robinhood', qualified: 11.20, ordinary: 11.20},
            { payer: 'Total for long term transactions (1099B)', qualified: 0, ordinary: 0, capitalGains: 15074 - 14633},
        ], // schedule b and d
        schedule1,
        type: 'married',
        qbiQualifiedPropertyUnadjustedBasis: (542.49+710.34+606+2099+269)
    };
    return f1040;
}
