import {sum} from "./sum";
import {Form8829} from "./TY2019_Form8829";

export class ScheduleC {
    public title = 'Schedule C';
    public renderEmpties = false;

    // inputs
    public info = {
        "principal business/profession": "",
        "enter code from instructions": "",
        "business name": "",
        "business address": "",
        "accounting method": "",
        "did you materially participate?": "",
        "did you start or acquire this business in 2019?": "",
        "must file form 1099?": "",
        "will you file all required forms 1099?": "",
    };
    public gross_receipts = 0;
    public returns = 0;
    public cogs = 0;
    public other_income = 0;
    public form8829: Form8829 | null = null;

    public expenses = {
        'l8_advertising': 0,
        'l9_car and truck expense': 0,
        'l10_commissions and fees': 0,
        'l11_contract labor': 0,
        'l12_depletion': 0,
        'l13_depreciation and sec 179 expense': 0,
        'l14_employee benefits': 0,
        'l15_insurance (not health)': 0,
        'l16_interest': 0,
        'l17_legal': 0,
        'l18_office expense': 0,
        'l19_pension and profit sharing': 0,
        'l20_rent or lease': 0,
        'l21_repairs and maintenance': 0,
        'l22_supplies': 0,
        'l23_taxes and licenses': 0,
        'l24a_travel': 0,
        'l24b_deductible meals': 0,
        'l25_utilities': 0,
        'l26_wages': 0,
        'l27a_other_expenses': 0,
    }

    public calculate() {
        const l1 = ({t: 'gross receipts or sales', val: this.gross_receipts});
        const l2 = ({t: 'returns', val: this.returns});
        const l3 = ({t: 'LINE 1 - LINE 2', val: l1.val - l2.val});
        const l4 = ({t: 'cogs', val: this.cogs});
        const l5 = ({t: 'Gross profit (line 3 - line 4)', val: l3.val - l4.val });
        const l6 = ({t: 'other income (see instructions)', val: this.other_income});
        const l7 = ({t: 'Gross income (line 5 + line 6)', val: l5.val + l6.val});

        //... expenses l8-27a
        const l28 = {t: 'add line 8 through 27a', val: sum(this.expenses)};
        const l29 = {t: 'tentative profit (l7 - l28)', val: l7.val - l28.val};

        // home office deduction
        const f8829_result = this.form8829?.calculate(l29.val);
        const l30 = {t: 'business use form 8829 line 25', val: (f8829_result?.l25.val) || 0, subForm: f8829_result};

        // the end
        const l31 = {t: 'net profit/loss', val: l29.val - l30.val};
        const {title, info, expenses} = this;
        return {title, ...info, l1, l2, l3, l4, l5, l6, l7, ...expenses, l28, l29, l30, l31};
    }
}
