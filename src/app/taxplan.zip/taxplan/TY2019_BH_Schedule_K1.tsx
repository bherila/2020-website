import {ScheduleC} from "./TY2019_ScheduleC";

export class TY2019_BH_Schedule_K1 extends ScheduleC {
    constructor() {
        super();
        this.title = "K1 Yap Herila";
        this.other_income = 2099.5;
        this.renderEmpties = false;
    }
}