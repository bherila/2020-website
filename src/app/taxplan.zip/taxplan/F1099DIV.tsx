export interface F1099DIV {
    payer: string;
    qualified: number;
    ordinary: number;
    capitalGains?: number;
    div199a?: number;
    foreignTaxPaid?: number;
}